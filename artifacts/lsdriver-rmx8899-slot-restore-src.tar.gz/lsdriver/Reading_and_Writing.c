#include <linux/errno.h>
#include <linux/bits.h>
#include <linux/limits.h>
#include <linux/mm.h>
#include <linux/huge_mm.h>
#include <linux/mutex.h>
#include <linux/pid.h>
#include <linux/sched/mm.h>
#include <linux/sched/task.h>
#include <linux/string.h>
#include <linux/vmalloc.h>
#include <asm/barrier.h>
#include <asm/memory.h>
#include <asm/pgtable.h>
#include <asm/pgtable-prot.h>
#include <asm/tlbflush.h>

#include "Reading_and_Writing.h"
#include "tool.h"

typedef int (*ls_access_remote_vm_t)(struct mm_struct *mm,
                                     unsigned long addr,
                                     void *buf,
                                     int len,
                                     unsigned int gup_flags);

static DEFINE_MUTEX(g_access_remote_vm_lock);
static ls_access_remote_vm_t g_access_remote_vm;
static bool g_access_remote_vm_resolved;

static ls_access_remote_vm_t ls_get_access_remote_vm(void)
{
    ls_access_remote_vm_t fn = READ_ONCE(g_access_remote_vm);

    if (fn || READ_ONCE(g_access_remote_vm_resolved))
        return fn;

    mutex_lock(&g_access_remote_vm_lock);
    if (!g_access_remote_vm_resolved) {
        unsigned long addr = resolve_unexported_symbol("access_remote_vm");

        if (addr)
            WRITE_ONCE(g_access_remote_vm, (ls_access_remote_vm_t)addr);
        WRITE_ONCE(g_access_remote_vm_resolved, true);
    }
    fn = READ_ONCE(g_access_remote_vm);
    mutex_unlock(&g_access_remote_vm_lock);
    return fn;
}

static pte_t *ls_get_kernel_pte(unsigned long va)
{
    u64 ttbr1;
    phys_addr_t pgd_phys;
    pgd_t *pgd_base;
    pgd_t *pgd;
    p4d_t *p4d;
    pud_t *pud;
    pmd_t *pmd;

    asm volatile("mrs %0, ttbr1_el1" : "=r"(ttbr1));
    pgd_phys = ttbr1 & GENMASK_ULL(47, PAGE_SHIFT);
    pgd_phys |= (ttbr1 & GENMASK_ULL(5, 2)) << 46;
    pgd_base = (pgd_t *)phys_to_virt(pgd_phys);

    pgd = pgd_base + pgd_index(va);
    if (pgd_none(*pgd) || pgd_bad(*pgd))
        return NULL;

    p4d = p4d_offset(pgd, va);
    if (p4d_none(*p4d) || p4d_bad(*p4d))
        return NULL;

    pud = pud_offset(p4d, va);
    if (pud_none(*pud) || pud_leaf(*pud) || pud_bad(*pud))
        return NULL;

    pmd = pmd_offset(pud, va);
    if (pmd_none(*pmd) || pmd_leaf(*pmd) || pmd_bad(*pmd))
        return NULL;

    return pte_offset_kernel(pmd, va);
}

/* Caller holds mm->mmap_lock for the complete translation and copy. */
static int ls_translate_user_va(struct mm_struct *mm, unsigned long va,
                                phys_addr_t *pa)
{
    struct vm_area_struct *vma;
    pgd_t *pgd;
    p4d_t *p4d;
    pud_t *pud;
    pmd_t *pmd;
    pte_t *ptep;
    pte_t pte;
    unsigned long pfn;

    if (!mm || !pa)
        return -EINVAL;

    vma = find_vma(mm, va);
    if (!vma || va < vma->vm_start)
        return -EFAULT;

    pgd = pgd_offset(mm, va);
    if (pgd_none(*pgd) || pgd_bad(*pgd))
        return -EFAULT;

    p4d = p4d_offset(pgd, va);
    if (p4d_none(*p4d) || p4d_bad(*p4d))
        return -EFAULT;

    pud = pud_offset(p4d, va);
    if (pud_none(*pud))
        return -EFAULT;
    if (pud_leaf(*pud)) {
        pfn = pud_pfn(*pud);
        if (!pfn_valid(pfn))
            return -EFAULT;
        *pa = ((phys_addr_t)pfn << PAGE_SHIFT) | (va & ~PUD_MASK);
        return 0;
    }
    if (pud_bad(*pud))
        return -EFAULT;

    pmd = pmd_offset(pud, va);
    if (pmd_none(*pmd))
        return -EFAULT;
    if (pmd_trans_huge(*pmd) || pmd_leaf(*pmd)) {
        pfn = pmd_pfn(*pmd);
        if (!pfn_valid(pfn))
            return -EFAULT;
        *pa = ((phys_addr_t)pfn << PAGE_SHIFT) | (va & ~PMD_MASK);
        return 0;
    }
    if (pmd_bad(*pmd))
        return -EFAULT;

    ptep = pte_offset_kernel(pmd, va);
    if (!ptep)
        return -EFAULT;
    pte = READ_ONCE(*ptep);
    if (!pte_present(pte))
        return -EFAULT;

    pfn = pte_pfn(pte);
    if (!pfn_valid(pfn))
        return -EFAULT;
    *pa = ((phys_addr_t)pfn << PAGE_SHIFT) | offset_in_page(va);
    return 0;
}

static int ls_read_remote_nocache(pid_t target_pid, unsigned long va,
                                  void *buffer, size_t size)
{
    static const pteval_t nocache_flags =
        PTE_TYPE_PAGE | PTE_VALID | PTE_AF | PTE_SHARED |
        PTE_PXN | PTE_UXN | PTE_ATTRINDX(MT_NORMAL_NC);
    struct pid *pid_struct;
    struct task_struct *task;
    struct mm_struct *mm;
    unsigned long slot_va;
    pte_t *slot_ptep;
    pte_t saved_pte;
    size_t done = 0;
    int ret = 0;

    pid_struct = find_get_pid(target_pid);
    if (!pid_struct)
        return -ESRCH;

    task = get_pid_task(pid_struct, PIDTYPE_PID);
    put_pid(pid_struct);
    if (!task)
        return -ESRCH;

    mm = get_task_mm(task);
    put_task_struct(task);
    if (!mm)
        return -EINVAL;

    slot_va = (unsigned long)vmalloc(PAGE_SIZE);
    if (!slot_va) {
        mmput(mm);
        return -ENOMEM;
    }
    memset((void *)slot_va, 0, PAGE_SIZE);

    slot_ptep = ls_get_kernel_pte(slot_va);
    if (!slot_ptep) {
        vfree((void *)slot_va);
        mmput(mm);
        return -EOPNOTSUPP;
    }
    saved_pte = READ_ONCE(*slot_ptep);

    mmap_read_lock(mm);
    while (done < size) {
        unsigned long current_va = va + done;
        size_t page_offset = offset_in_page(current_va);
        size_t chunk = min_t(size_t, size - done, PAGE_SIZE - page_offset);
        phys_addr_t pa;
        unsigned long pfn;
        struct page *page;
        pte_t mapped_pte;

        ret = ls_translate_user_va(mm, current_va, &pa);
        if (ret)
            break;

        pfn = PHYS_PFN(pa);
        if (!pfn_valid(pfn)) {
            ret = -EFAULT;
            break;
        }
        page = pfn_to_page(pfn);
        if (!get_page_unless_zero(page)) {
            ret = -EFAULT;
            break;
        }

        mapped_pte = pfn_pte(pfn, __pgprot(nocache_flags));
        set_pte(slot_ptep, mapped_pte);
        asm volatile("dsb ishst" ::: "memory");
        flush_tlb_kernel_range(slot_va, slot_va + PAGE_SIZE);

        memcpy((u8 *)buffer + done,
               (void *)(slot_va + offset_in_page(pa)), chunk);
        put_page(page);
        done += chunk;
    }
    set_pte(slot_ptep, saved_pte);
    asm volatile("dsb ishst" ::: "memory");
    flush_tlb_kernel_range(slot_va, slot_va + PAGE_SIZE);
    mmap_read_unlock(mm);
    vfree((void *)slot_va);
    mmput(mm);
    return ret;
}

long phys_rw_memory(pid_t target_pid, unsigned long va, void *buffer,
                    size_t size, int is_write)
{
    ls_access_remote_vm_t access_remote_vm_fn;
    struct pid *pid_struct;
    struct task_struct *task;
    struct mm_struct *mm;
    unsigned int gup_flags = FOLL_FORCE;
    int copied;

    if (target_pid <= 0 || !buffer || !size)
        return -EINVAL;
    if (size > INT_MAX)
        return -E2BIG;
    va = untagged_addr(va);
    if (!va)
        return -EINVAL;
    if (va > ULONG_MAX - (size - 1))
        return -EOVERFLOW;

    access_remote_vm_fn = ls_get_access_remote_vm();
    if (!access_remote_vm_fn) {
        if (!is_write)
            return ls_read_remote_nocache(target_pid, va, buffer, size);
        return -EOPNOTSUPP;
    }
    if (is_write)
        gup_flags |= FOLL_WRITE;

    pid_struct = find_get_pid(target_pid);
    if (!pid_struct)
        return -ESRCH;

    task = get_pid_task(pid_struct, PIDTYPE_PID);
    put_pid(pid_struct);
    if (!task)
        return -ESRCH;

    mm = get_task_mm(task);
    put_task_struct(task);
    if (!mm)
        return -EINVAL;

    copied = access_remote_vm_fn(mm, va, buffer, (int)size, gup_flags);
    mmput(mm);

    if (copied < 0)
        return copied;
    if (copied != (int)size)
        return -EFAULT;
    return 0;
}

int read_phys(pid_t pid, u64 addr, void *buf, size_t size)
{
    return (int)phys_rw_memory(pid, (unsigned long)addr, buf, size, 0);
}

int write_phys(pid_t pid, u64 addr, void *buf, size_t size)
{
    return (int)phys_rw_memory(pid, (unsigned long)addr, buf, size, 1);
}
