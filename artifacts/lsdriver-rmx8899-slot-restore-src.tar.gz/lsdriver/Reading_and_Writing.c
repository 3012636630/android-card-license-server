#include <linux/errno.h>
#include <linux/highmem.h>
#include <linux/limits.h>
#include <linux/mm.h>
#include <linux/mutex.h>
#include <linux/pid.h>
#include <linux/sched/mm.h>
#include <linux/sched/task.h>
#include <linux/string.h>

#include "Reading_and_Writing.h"
#include "tool.h"

typedef int (*ls_access_remote_vm_t)(struct mm_struct *mm,
                                     unsigned long addr,
                                     void *buf,
                                     int len,
                                     unsigned int gup_flags);
typedef long (*ls_get_user_pages_remote_t)(struct mm_struct *mm,
                                           unsigned long start,
                                           unsigned long nr_pages,
                                           unsigned int gup_flags,
                                           struct page **pages,
                                           int *locked);

static DEFINE_MUTEX(g_access_remote_vm_lock);
static ls_access_remote_vm_t g_access_remote_vm;
static bool g_access_remote_vm_resolved;
static DEFINE_MUTEX(g_get_user_pages_remote_lock);
static ls_get_user_pages_remote_t g_get_user_pages_remote;
static bool g_get_user_pages_remote_resolved;

static ls_access_remote_vm_t ls_get_access_remote_vm(void)
{
    ls_access_remote_vm_t fn = READ_ONCE(g_access_remote_vm);

    if (fn || READ_ONCE(g_access_remote_vm_resolved))
        return fn;

    mutex_lock(&g_access_remote_vm_lock);
    if (!g_access_remote_vm_resolved) {
        unsigned long addr = resolve_unexported_symbol("access_remote_vm");

        if (addr)
            WRITE_ONCE(g_access_remote_vm, (ls_access_remote_vm_t)addr);
        WRITE_ONCE(g_access_remote_vm_resolved, true);
    }
    fn = READ_ONCE(g_access_remote_vm);
    mutex_unlock(&g_access_remote_vm_lock);
    return fn;
}

static ls_get_user_pages_remote_t ls_get_get_user_pages_remote(void)
{
    ls_get_user_pages_remote_t fn = READ_ONCE(g_get_user_pages_remote);

    if (fn || READ_ONCE(g_get_user_pages_remote_resolved))
        return fn;

    mutex_lock(&g_get_user_pages_remote_lock);
    if (!g_get_user_pages_remote_resolved) {
        unsigned long addr = resolve_unexported_symbol("get_user_pages_remote");

        if (addr)
            WRITE_ONCE(g_get_user_pages_remote,
                       (ls_get_user_pages_remote_t)addr);
        WRITE_ONCE(g_get_user_pages_remote_resolved, true);
    }
    fn = READ_ONCE(g_get_user_pages_remote);
    mutex_unlock(&g_get_user_pages_remote_lock);
    return fn;
}

static void ls_copy_nontemporal(void *dst, const void *src, size_t size)
{
    u8 *out = dst;
    const u8 *in = src;

    while (size) {
        const u8 *aligned = (const u8 *)((unsigned long)in & ~0xFUL);
        size_t offset = (size_t)(in - aligned);
        size_t chunk = min_t(size_t, size, 16U - offset);
        u64 low;
        u64 high;
        u8 block[16];

        /* Preserve the coherent WB mapping; LDNP avoids unsafe NC aliases. */
        asm volatile("ldnp %0, %1, [%2]"
                     : "=&r"(low), "=&r"(high)
                     : "r"(aligned)
                     : "memory");
        memcpy(block, &low, sizeof(low));
        memcpy(block + sizeof(low), &high, sizeof(high));
        memcpy(out, block + offset, chunk);

        out += chunk;
        in += chunk;
        size -= chunk;
    }
}

static int ls_read_remote_nontemporal(pid_t target_pid, unsigned long va,
                                      void *buffer, size_t size)
{
    ls_get_user_pages_remote_t get_user_pages_remote_fn;
    struct pid *pid_struct;
    struct task_struct *task;
    struct mm_struct *mm;
    size_t done = 0;
    int ret = 0;

    get_user_pages_remote_fn = ls_get_get_user_pages_remote();
    if (!get_user_pages_remote_fn)
        return -EOPNOTSUPP;

    pid_struct = find_get_pid(target_pid);
    if (!pid_struct)
        return -ESRCH;

    task = get_pid_task(pid_struct, PIDTYPE_PID);
    put_pid(pid_struct);
    if (!task)
        return -ESRCH;

    mm = get_task_mm(task);
    put_task_struct(task);
    if (!mm)
        return -EINVAL;

    mmap_read_lock(mm);
    while (done < size) {
        unsigned long current_va = va + done;
        size_t page_offset = offset_in_page(current_va);
        size_t chunk = min_t(size_t, size - done, PAGE_SIZE - page_offset);
        struct page *page = NULL;
        void *mapped;
        long pinned;

        pinned = get_user_pages_remote_fn(mm, current_va, 1,
                                          FOLL_FORCE | FOLL_NOFAULT,
                                          &page, NULL);
        if (pinned != 1 || !page) {
            ret = pinned < 0 ? (int)pinned : -EFAULT;
            break;
        }

        mapped = kmap_local_page(page);
        ls_copy_nontemporal((u8 *)buffer + done,
                            (u8 *)mapped + page_offset, chunk);
        kunmap_local(mapped);
        put_page(page);
        done += chunk;
    }
    mmap_read_unlock(mm);
    mmput(mm);

    if (ret)
        return ret;
    return done == size ? 0 : -EFAULT;
}

long phys_rw_memory(pid_t target_pid, unsigned long va, void *buffer,
                    size_t size, int is_write)
{
    ls_access_remote_vm_t access_remote_vm_fn;
    struct pid *pid_struct;
    struct task_struct *task;
    struct mm_struct *mm;
    int copied;

    if (target_pid <= 0 || !buffer || !size)
        return -EINVAL;
    if (size > INT_MAX)
        return -E2BIG;
    va = untagged_addr(va);
    if (!va)
        return -EINVAL;
    if (va > ULONG_MAX - (size - 1))
        return -EOVERFLOW;

    if (!is_write)
        return ls_read_remote_nontemporal(target_pid, va, buffer, size);

    access_remote_vm_fn = ls_get_access_remote_vm();
    if (!access_remote_vm_fn)
        return -EOPNOTSUPP;

    pid_struct = find_get_pid(target_pid);
    if (!pid_struct)
        return -ESRCH;

    task = get_pid_task(pid_struct, PIDTYPE_PID);
    put_pid(pid_struct);
    if (!task)
        return -ESRCH;

    mm = get_task_mm(task);
    put_task_struct(task);
    if (!mm)
        return -EINVAL;

    copied = access_remote_vm_fn(mm, va, buffer, (int)size,
                                 FOLL_FORCE | FOLL_WRITE);
    mmput(mm);

    if (copied < 0)
        return copied;
    if (copied != (int)size)
        return -EFAULT;
    return 0;
}

int read_phys(pid_t pid, u64 addr, void *buf, size_t size)
{
    return (int)phys_rw_memory(pid, (unsigned long)addr, buf, size, 0);
}

int write_phys(pid_t pid, u64 addr, void *buf, size_t size)
{
    return (int)phys_rw_memory(pid, (unsigned long)addr, buf, size, 1);
}
