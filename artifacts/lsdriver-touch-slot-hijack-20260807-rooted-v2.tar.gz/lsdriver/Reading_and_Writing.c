#include <linux/errno.h>
#include <linux/limits.h>
#include <linux/mm.h>
#include <linux/mutex.h>
#include <linux/pid.h>
#include <linux/sched/mm.h>
#include <linux/sched/task.h>

#include "Reading_and_Writing.h"
#include "tool.h"

/*
 * Keep the remote-memory operation inside the running kernel.
 *
 * Directly walking pgd/p4d/pud/pmd/pte structures from an external Android
 * module makes private MM structure layout, THP, migration entries and the
 * linear-map status of every PFN part of the module ABI.  Vendor kernels do
 * not promise that ABI even when vermagic and CONFIG_MODVERSIONS match.
 * access_remote_vm() is the in-kernel implementation used for this job: it
 * takes the mmap lock, faults/pins pages through GUP, maps highmem safely and
 * performs the correct user-page cache maintenance.
 *
 * Android GKI does not export this helper to modules.  Resolve its text address
 * once through the already-supported kprobe resolver and call it with the
 * exact declaration shared by Android 5.10 through 6.12.
 */
typedef int (*ls_access_remote_vm_t)(struct mm_struct *mm,
                                     unsigned long addr,
                                     void *buf,
                                     int len,
                                     unsigned int gup_flags);

static DEFINE_MUTEX(g_access_remote_vm_lock);
static ls_access_remote_vm_t g_access_remote_vm;
static bool g_access_remote_vm_resolved;

static ls_access_remote_vm_t ls_get_access_remote_vm(void)
{
    ls_access_remote_vm_t fn = READ_ONCE(g_access_remote_vm);

    if (fn || READ_ONCE(g_access_remote_vm_resolved))
        return fn;

    mutex_lock(&g_access_remote_vm_lock);
    if (!g_access_remote_vm_resolved) {
        unsigned long addr = resolve_unexported_symbol("access_remote_vm");

        if (addr)
            WRITE_ONCE(g_access_remote_vm, (ls_access_remote_vm_t)addr);
        WRITE_ONCE(g_access_remote_vm_resolved, true);
    }
    fn = READ_ONCE(g_access_remote_vm);
    mutex_unlock(&g_access_remote_vm_lock);
    return fn;
}

long phys_rw_memory(pid_t target_pid, unsigned long va, void *buffer,
                    size_t size, int is_write)
{
    ls_access_remote_vm_t access_remote_vm_fn;
    struct pid *pid_struct;
    struct task_struct *task;
    struct mm_struct *mm;
    unsigned int gup_flags = FOLL_FORCE;
    int copied;

    if (target_pid <= 0 || !buffer || !va || !size)
        return -EINVAL;
    if (size > INT_MAX)
        return -E2BIG;
    if (va > ULONG_MAX - (size - 1))
        return -EOVERFLOW;
    if (is_write)
        gup_flags |= FOLL_WRITE;

    access_remote_vm_fn = ls_get_access_remote_vm();
    if (!access_remote_vm_fn)
        return -EOPNOTSUPP;

    pid_struct = find_get_pid(target_pid);
    if (!pid_struct)
        return -ESRCH;

    task = get_pid_task(pid_struct, PIDTYPE_PID);
    put_pid(pid_struct);
    if (!task)
        return -ESRCH;

    mm = get_task_mm(task);
    put_task_struct(task);
    if (!mm)
        return -EINVAL;

    copied = access_remote_vm_fn(mm, va, buffer, (int)size, gup_flags);
    mmput(mm);

    if (copied < 0)
        return copied;
    if (copied != (int)size)
        return -EFAULT;
    return 0;
}

int read_phys(pid_t pid, u64 addr, void *buf, size_t size)
{
    return (int)phys_rw_memory(pid, (unsigned long)addr, buf, size, 0);
}

int write_phys(pid_t pid, u64 addr, void *buf, size_t size)
{
    return (int)phys_rw_memory(pid, (unsigned long)addr, buf, size, 1);
}
