#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x7c24b32d, "module_layout" },
	{ 0xdcb764ad, "memset" },
	{ 0x4829a47e, "memcpy" },
	{ 0x3fcaa46c, "input_mt_report_slot_state" },
	{ 0x3b938c8d, "input_event" },
	{ 0x837ac1f4, "input_set_abs_params" },
	{ 0xa467bfcc, "input_unregister_handler" },
	{ 0xac72b90e, "input_register_handler" },
	{ 0x723d2d0b, "remap_pfn_range" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x6b2941b2, "__arch_copy_to_user" },
	{ 0x599fb41c, "kvmalloc_node" },
	{ 0x7aa1756e, "kvfree" },
	{ 0x66e0c8e3, "anon_inode_getfd" },
	{ 0x4044ba28, "__tracepoint_sched_switch" },
	{ 0xdbeeece6, "tracepoint_probe_unregister" },
	{ 0x95e102ab, "tracepoint_probe_register" },
	{ 0x294b9ea1, "on_each_cpu" },
	{ 0xb1307de2, "init_task" },
	{ 0x1e6d26a8, "strstr" },
	{ 0xd3c5d4d0, "put_pid" },
	{ 0xdca62649, "find_get_pid" },
	{ 0x9166fada, "strncpy" },
	{ 0x98cf60b3, "strlen" },
	{ 0xe4bbc1dd, "kimage_voffset" },
	{ 0xc56a41e6, "vabits_actual" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x20d81059, "up_write" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x28ed2847, "down_write" },
	{ 0x6b50e951, "up_read" },
	{ 0x3355da1c, "down_read" },
	{ 0x806ab898, "find_vma" },
	{ 0x4302d0eb, "free_pages" },
	{ 0x6a5cb5ee, "__get_free_pages" },
	{ 0x9a80f9a6, "__put_task_struct" },
	{ 0x2469810f, "__rcu_read_unlock" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0x8d522714, "__rcu_read_lock" },
	{ 0x825a3481, "mmput" },
	{ 0x51e77c97, "pfn_valid" },
	{ 0xa378a2f4, "get_task_mm" },
	{ 0x12aec6f2, "find_vpid" },
	{ 0x918779bc, "pid_task" },
	{ 0x9688de8b, "memstart_addr" },
	{ 0x4b0a3f52, "gic_nonsecure_priorities" },
	{ 0x8b9f70c7, "cpu_hwcaps" },
	{ 0xec2fc692, "cpu_hwcap_keys" },
	{ 0x14b89635, "arm64_const_caps_ready" },
	{ 0x8900b200, "kmalloc_caches" },
	{ 0x55686530, "__arch_clear_user" },
	{ 0xaf507de1, "__arch_copy_from_user" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xdd4d55b6, "_raw_read_unlock" },
	{ 0xe2d5255a, "strcmp" },
	{ 0xfe8c61f0, "_raw_read_lock" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0xb38391e9, "kmem_cache_alloc_trace" },
	{ 0x37a0cba, "kfree" },
	{ 0x9b2b597c, "sysfs_remove_link" },
	{ 0xf524bddc, "kobject_del" },
	{ 0x4d9b652b, "rb_erase" },
	{ 0x40235c98, "_raw_write_unlock" },
	{ 0xe68efe41, "_raw_write_lock" },
	{ 0xdd64e639, "strscpy" },
	{ 0xaf56600a, "arm64_use_ng_mappings" },
	{ 0xa6e1a69d, "kick_all_cpus_sync" },
	{ 0xe2e0c7c6, "__flush_icache_range" },
	{ 0x4531ab62, "copy_from_kernel_nofault" },
	{ 0x94961283, "vunmap" },
	{ 0xdfc04014, "stop_machine" },
	{ 0x1270d593, "vmap" },
	{ 0x5e0556c0, "vmalloc_to_page" },
	{ 0xc31db0ce, "is_vmalloc_addr" },
	{ 0x18b23dc5, "unregister_kprobe" },
	{ 0xc5850110, "printk" },
	{ 0xc502eb6d, "register_kprobe" },
};

MODULE_INFO(depends, "");

