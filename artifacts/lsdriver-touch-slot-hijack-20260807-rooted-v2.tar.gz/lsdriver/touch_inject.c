#include <linux/kernel.h>
#include <linux/input.h>
#include <linux/input/mt.h>
#include <linux/device.h>
#include <linux/slab.h>
#include <linux/version.h>
#include <linux/compiler.h>
#include <linux/ktime.h>
#include <linux/mutex.h>
#include <linux/string.h>

#include "quiet_log.h"
#include "coom.h"
#include "touch_inject.h"

#ifndef INPUT_MT_POINTER
#define INPUT_MT_POINTER 0x0001
#endif
#ifndef INPUT_MT_DIRECT
#define INPUT_MT_DIRECT 0x0002
#endif
#ifndef INPUT_MT_DROP_UNUSED
#define INPUT_MT_DROP_UNUSED 0x0004
#endif

/*
 * The reference implementation shares the physical touchscreen.  Its slot
 * pool is partitioned once: physical_slots stay visible to the panel driver,
 * while virtual_slots are reserved for injected contacts.  A report briefly
 * opens the complete slot range, emits one Type-B contact, then restores the
 * physical range before SYN_REPORT.  This is the key detail that keeps a
 * physical joystick contact alive while an injected contact is changed.
 */
#define MAX_TOUCH_SLOTS 16
#define DEFAULT_ORIGINAL_SLOTS 10

struct vt_context vt = {
    .tracking_ids = { -1, -1, -1, -1, -1, -1 },
    .initialized = false,
};

static DEFINE_MUTEX(vt_lock);
static struct input_dev *physical_dev;
static int original_slots;
static int physical_slots;
static int virtual_slots;
static int virtual_slot_base;
static unsigned int saved_slot_min;
static unsigned int saved_slot_max;
static int saved_slot_fuzz;
static int saved_slot_flat;
static int saved_slot_resolution;
static unsigned int saved_mt_flags;
static bool saved_key_btn_touch;
static bool saved_key_tool_finger;
static bool saved_key_tool_doubletap;
static bool saved_key_tool_tripletap;
static bool saved_key_tool_quadtap;
static bool saved_key_tool_quinttap;
static bool key_state_saved;
static bool global_keys_locked;
static u32 tracking_seed;
static u32 physical_seq;
static u32 last_physical_mask;
static int physical_cursor;
static u64 source_area;

static bool supports_abs_axis(struct input_dev *dev, unsigned int code)
{
    return dev && dev->absinfo && test_bit(code, dev->absbit);
}

static void set_global_key_bits(struct input_dev *dev, bool enable)
{
    if (!dev)
        return;

    if (enable) {
        if (saved_key_btn_touch)
            set_bit(BTN_TOUCH, dev->keybit);
        if (saved_key_tool_finger)
            set_bit(BTN_TOOL_FINGER, dev->keybit);
        if (saved_key_tool_doubletap)
            set_bit(BTN_TOOL_DOUBLETAP, dev->keybit);
        if (saved_key_tool_tripletap)
            set_bit(BTN_TOOL_TRIPLETAP, dev->keybit);
        if (saved_key_tool_quadtap)
            set_bit(BTN_TOOL_QUADTAP, dev->keybit);
        if (saved_key_tool_quinttap)
            set_bit(BTN_TOOL_QUINTTAP, dev->keybit);
    } else {
        clear_bit(BTN_TOUCH, dev->keybit);
        clear_bit(BTN_TOOL_FINGER, dev->keybit);
        clear_bit(BTN_TOOL_DOUBLETAP, dev->keybit);
        clear_bit(BTN_TOOL_TRIPLETAP, dev->keybit);
        clear_bit(BTN_TOOL_QUADTAP, dev->keybit);
        clear_bit(BTN_TOOL_QUINTTAP, dev->keybit);
    }
}

static int vt_active_count(void)
{
    int i;
    int count = 0;

    for (i = 0; i < virtual_slots; i++)
        if (vt.tracking_ids[i] != -1)
            count++;
    return count;
}

static int next_tracking_id(void)
{
    u32 id;

    do {
        tracking_seed = tracking_seed * 1664525U + 1013904223U;
        id = tracking_seed & 0x3fffffffU;
    } while (id == 0 || id == 0x3fffffffU);
    return (int)id;
}

static int physical_active_count(void)
{
    struct input_mt *mt;
    int i;
    int count = 0;

    if (!physical_dev || !physical_dev->mt)
        return 0;
    mt = physical_dev->mt;
    for (i = 0; i < physical_slots; i++)
        if (input_mt_get_value(&mt->slots[i], ABS_MT_TRACKING_ID) != -1)
            count++;
    return count;
}

static void update_global_keys(void)
{
    struct input_dev *dev = physical_dev;
    int count;
    bool relock;

    if (!dev)
        return;

    count = physical_active_count() + vt_active_count();
    relock = global_keys_locked;

    /* input_event validates EV_KEY against keybit.  Restore capabilities only
     * for this synthetic frame when physical keys are currently locked out. */
    if (relock)
        set_global_key_bits(dev, true);

    if (saved_key_btn_touch)
        input_event(dev, EV_KEY, BTN_TOUCH, count > 0);
    if (saved_key_tool_finger)
        input_event(dev, EV_KEY, BTN_TOOL_FINGER, count == 1);
    if (saved_key_tool_doubletap)
        input_event(dev, EV_KEY, BTN_TOOL_DOUBLETAP, count >= 2);
    if (saved_key_tool_tripletap)
        input_event(dev, EV_KEY, BTN_TOOL_TRIPLETAP, count >= 3);
    if (saved_key_tool_quadtap)
        input_event(dev, EV_KEY, BTN_TOOL_QUADTAP, count >= 4);
    if (saved_key_tool_quinttap)
        input_event(dev, EV_KEY, BTN_TOOL_QUINTTAP, count >= 5);

    if (relock)
        set_global_key_bits(dev, false);
}

static void report_optional_axis(struct input_dev *dev, unsigned int code,
                                 int value)
{
    if (supports_abs_axis(dev, code))
        input_event(dev, EV_ABS, code, value);
}

static int send_report_locked(int slot, int x, int y, bool touching)
{
    struct input_dev *dev = physical_dev;
    struct input_mt *mt;
    int hw_slot;
    int old_slot;
    int tracking_id;

    if (!dev || !dev->mt)
        return -ENODEV;
    if (slot < 0 || slot >= virtual_slots)
        return -EINVAL;
    if (touching && vt.tracking_ids[slot] == -1)
        return -EINVAL;

    mt = dev->mt;
    hw_slot = virtual_slot_base + slot;
    tracking_id = touching ? vt.tracking_ids[slot] : -1;
    old_slot = mt->slot;

    /* Match the reference scheme exactly: expose all slots only while the
     * synthetic contact is written, then hand the physical range back. */
    mt->num_slots = original_slots;
    input_event(dev, EV_ABS, ABS_MT_SLOT, hw_slot);
    input_event(dev, EV_ABS, ABS_MT_TRACKING_ID, tracking_id);
    if (touching) {
        input_event(dev, EV_ABS, ABS_MT_POSITION_X, x);
        input_event(dev, EV_ABS, ABS_MT_POSITION_Y, y);
        report_optional_axis(dev, ABS_MT_TOUCH_MAJOR, vt.touch_major[slot]);
        report_optional_axis(dev, ABS_MT_TOUCH_MINOR, vt.touch_minor[slot]);
        report_optional_axis(dev, ABS_MT_WIDTH_MAJOR, vt.touch_major[slot]);
        report_optional_axis(dev, ABS_MT_PRESSURE, vt.pressure[slot]);
        report_optional_axis(dev, ABS_MT_ORIENTATION, vt.orientation[slot]);
        report_optional_axis(dev, ABS_X, x);
        report_optional_axis(dev, ABS_Y, y);
    }

    /* Do not run the MT frame finalizer here: it would finalize physical
     * slots that were not present in this synthetic frame. */
    input_event(dev, EV_ABS, ABS_MT_SLOT, old_slot);
    mt->num_slots = physical_slots;
    update_global_keys();
    input_event(dev, EV_SYN, SYN_REPORT, 0);
    return 0;
}

static int match_touchscreen(struct device *device, void *data)
{
    struct input_dev *dev = to_input_dev(device);
    struct input_dev **result = data;

    if (!dev || !dev->mt || !dev->absinfo ||
        !test_bit(EV_ABS, dev->evbit) ||
        !test_bit(ABS_MT_SLOT, dev->absbit) ||
        !test_bit(ABS_MT_POSITION_X, dev->absbit) ||
        !test_bit(ABS_MT_POSITION_Y, dev->absbit) ||
        !test_bit(BTN_TOUCH, dev->keybit))
        return 0;

    *result = dev;
    return 1;
}

static void remember_source_capabilities(struct input_dev *dev)
{
    saved_key_btn_touch = test_bit(BTN_TOUCH, dev->keybit);
    saved_key_tool_finger = test_bit(BTN_TOOL_FINGER, dev->keybit);
    saved_key_tool_doubletap = test_bit(BTN_TOOL_DOUBLETAP, dev->keybit);
    saved_key_tool_tripletap = test_bit(BTN_TOOL_TRIPLETAP, dev->keybit);
    saved_key_tool_quadtap = test_bit(BTN_TOOL_QUADTAP, dev->keybit);
    saved_key_tool_quinttap = test_bit(BTN_TOOL_QUINTTAP, dev->keybit);
    saved_slot_min = dev->absinfo[ABS_MT_SLOT].minimum;
    saved_slot_max = dev->absinfo[ABS_MT_SLOT].maximum;
    saved_slot_fuzz = dev->absinfo[ABS_MT_SLOT].fuzz;
    saved_slot_flat = dev->absinfo[ABS_MT_SLOT].flat;
    saved_slot_resolution = dev->absinfo[ABS_MT_SLOT].resolution;
    saved_mt_flags = dev->mt->flags;
    key_state_saved = true;
}

static int initialize_slot_partition(struct input_dev *dev)
{
    int detected_slots;

    if (!dev || !dev->mt)
        return -ENODEV;

    detected_slots = dev->mt->num_slots;
    if (detected_slots < DEFAULT_ORIGINAL_SLOTS)
        return -ENOSPC;

    original_slots = DEFAULT_ORIGINAL_SLOTS;
    virtual_slots = VIRTUAL_SLOTS;
    physical_slots = original_slots - virtual_slots;
    virtual_slot_base = physical_slots;

    remember_source_capabilities(dev);
    dev->mt->num_slots = physical_slots;
    dev->mt->flags &= ~INPUT_MT_DROP_UNUSED;
    dev->mt->flags |= INPUT_MT_DIRECT;
    dev->mt->flags &= ~INPUT_MT_POINTER;
    input_set_abs_params(dev, ABS_MT_SLOT, 0, original_slots - 1, 0, 0);
    return 0;
}

static void restore_slot_partition(void)
{
    struct input_dev *dev = physical_dev;

    if (!dev || !dev->mt || !key_state_saved)
        return;
    dev->mt->num_slots = original_slots;
    dev->mt->flags = saved_mt_flags;
    input_set_abs_params(dev, ABS_MT_SLOT, saved_slot_min, saved_slot_max,
                         saved_slot_fuzz, saved_slot_flat);
    dev->absinfo[ABS_MT_SLOT].resolution = saved_slot_resolution;
    set_global_key_bits(dev, true);
}

static const struct input_device_id vtouch_ids[] = {
    { .driver_info = 1 },
    { },
};

static int spy_connect(struct input_handler *handler, struct input_dev *dev,
                       const struct input_device_id *id)
{
    struct input_dev *candidate = NULL;
    u64 area;

    (void)handler;
    (void)id;
    if (!match_touchscreen(&dev->dev, &candidate))
        return -ENODEV;

    area = (u64)dev->absinfo[ABS_MT_POSITION_X].maximum *
           (u64)dev->absinfo[ABS_MT_POSITION_Y].maximum;
    if (!physical_dev || area > source_area) {
        physical_dev = dev;
        source_area = area;
    }
    return -ENODEV;
}

static struct input_handler vtouch_spy = {
    .connect = spy_connect,
    .name = "input_panel_probe",
    .id_table = vtouch_ids,
};

static int discover_source_panel(void)
{
    int ret;

    physical_dev = NULL;
    source_area = 0;
    ret = input_register_handler(&vtouch_spy);
    if (ret)
        return ret;
    input_unregister_handler(&vtouch_spy);
    if (!physical_dev)
        return -ENODEV;
    get_device(&physical_dev->dev);
    vt.source_dev = physical_dev;
    vt.dev = physical_dev;
    return 0;
}

static void release_discovered_source(void)
{
    if (physical_dev) {
        put_device(&physical_dev->dev);
        physical_dev = NULL;
    }
    vt.source_dev = NULL;
    vt.dev = NULL;
    source_area = 0;
}

int v_touch_init(int *max_x, int *max_y)
{
    int ret;

    if (!max_x || !max_y)
        return -EINVAL;

    mutex_lock(&vt_lock);
    if (vt.initialized) {
        *max_x = vt.max_x;
        *max_y = vt.max_y;
        mutex_unlock(&vt_lock);
        return 0;
    }

    ret = discover_source_panel();
    if (ret)
        goto out;
    ret = initialize_slot_partition(physical_dev);
    if (ret)
        goto fail_source;

    vt.max_x = physical_dev->absinfo[ABS_MT_POSITION_X].maximum;
    vt.max_y = physical_dev->absinfo[ABS_MT_POSITION_Y].maximum;
    tracking_seed = (u32)ktime_get_ns() ^ (u32)(unsigned long)physical_dev;
    memset(vt.tracking_ids, 0xff, sizeof(vt.tracking_ids));
    memset(vt.pressure, 0, sizeof(vt.pressure));
    memset(vt.touch_major, 0, sizeof(vt.touch_major));
    memset(vt.touch_minor, 0, sizeof(vt.touch_minor));
    memset(vt.orientation, 0, sizeof(vt.orientation));
    physical_seq = 0;
    last_physical_mask = 0;
    physical_cursor = -1;
    global_keys_locked = false;
    vt.initialized = true;
    *max_x = vt.max_x;
    *max_y = vt.max_y;
    mutex_unlock(&vt_lock);
    return 0;

fail_source:
    release_discovered_source();
out:
    vt.max_x = 0;
    vt.max_y = 0;
    mutex_unlock(&vt_lock);
    return ret;
}

static void reset_contacts_locked(void)
{
    int i;

    for (i = 0; i < virtual_slots; i++) {
        if (vt.tracking_ids[i] == -1)
            continue;
        vt.tracking_ids[i] = -1;
        send_report_locked(i, 0, 0, false);
    }
}

int v_touch_reset_contact(int logical_slot)
{
    int ret = 0;

    if (logical_slot < 0 || logical_slot >= VIRTUAL_SLOTS)
        return -EINVAL;
    mutex_lock(&vt_lock);
    if (!vt.initialized || !physical_dev) {
        ret = -ENODEV;
        goto out;
    }
    if (vt.tracking_ids[logical_slot] != -1) {
        vt.tracking_ids[logical_slot] = -1;
        ret = send_report_locked(logical_slot, 0, 0, false);
    }
out:
    mutex_unlock(&vt_lock);
    return ret;
}

void v_touch_reset_contacts(void)
{
    mutex_lock(&vt_lock);
    if (vt.initialized && physical_dev)
        reset_contacts_locked();
    mutex_unlock(&vt_lock);
}

void v_touch_destroy(void)
{
    mutex_lock(&vt_lock);
    if (!vt.initialized) {
        mutex_unlock(&vt_lock);
        return;
    }

    reset_contacts_locked();
    restore_slot_partition();
    global_keys_locked = false;
    vt.initialized = false;
    release_discovered_source();
    original_slots = 0;
    physical_slots = 0;
    virtual_slots = 0;
    virtual_slot_base = 0;
    key_state_saved = false;
    mutex_unlock(&vt_lock);
}

static int scale_contact_attribute(struct input_dev *dev, unsigned int code,
                                   int normalized, bool signed_value)
{
    const struct input_absinfo *info;
    s64 numerator;

    if (!supports_abs_axis(dev, code))
        return 0;
    info = &dev->absinfo[code];
    if (signed_value) {
        normalized = clamp(normalized, -1024, 1024);
        numerator = (s64)(normalized + 1024) *
                    (info->maximum - info->minimum);
        return info->minimum + div_s64(numerator, 2048);
    }
    normalized = clamp(normalized, 0, 1024);
    numerator = (s64)normalized * (info->maximum - info->minimum);
    return info->minimum + div_s64(numerator, 1024);
}

static void update_virtual_contact_attributes(const struct ls_touch_cmd *cmd)
{
    u32 seed;
    int slot = cmd->slot;

    seed = (u32)cmd->x * 1103515245U ^ (u32)cmd->y * 2654435761U ^
           (u32)slot * 2246822519U;
    if (supports_abs_axis(physical_dev, ABS_MT_PRESSURE) &&
        (cmd->attribute_mask & LS_TOUCH_ATTR_PRESSURE))
        vt.pressure[slot] = scale_contact_attribute(physical_dev,
                                                     ABS_MT_PRESSURE,
                                                     cmd->pressure, false);
    else if (supports_abs_axis(physical_dev, ABS_MT_PRESSURE) &&
             cmd->action == op_down)
        vt.pressure[slot] = scale_contact_attribute(physical_dev,
                                                     ABS_MT_PRESSURE,
                                                     360 + seed % 221, false);

    if (supports_abs_axis(physical_dev, ABS_MT_TOUCH_MAJOR) &&
        (cmd->attribute_mask & LS_TOUCH_ATTR_TOUCH_MAJOR))
        vt.touch_major[slot] = scale_contact_attribute(physical_dev,
                                                        ABS_MT_TOUCH_MAJOR,
                                                        cmd->touch_major, false);
    else if (supports_abs_axis(physical_dev, ABS_MT_TOUCH_MAJOR) &&
             cmd->action == op_down)
        vt.touch_major[slot] = scale_contact_attribute(physical_dev,
                                                        ABS_MT_TOUCH_MAJOR,
                                                        110 + (seed >> 8) % 111,
                                                        false);

    if (supports_abs_axis(physical_dev, ABS_MT_TOUCH_MINOR) &&
        (cmd->attribute_mask & LS_TOUCH_ATTR_TOUCH_MINOR))
        vt.touch_minor[slot] = scale_contact_attribute(physical_dev,
                                                        ABS_MT_TOUCH_MINOR,
                                                        cmd->touch_minor, false);
    else if (supports_abs_axis(physical_dev, ABS_MT_TOUCH_MINOR) &&
             cmd->action == op_down)
        vt.touch_minor[slot] = scale_contact_attribute(physical_dev,
                                                        ABS_MT_TOUCH_MINOR,
                                                        70 + (seed >> 16) % 91,
                                                        false);

    if (supports_abs_axis(physical_dev, ABS_MT_ORIENTATION) &&
        (cmd->attribute_mask & LS_TOUCH_ATTR_ORIENTATION))
        vt.orientation[slot] = scale_contact_attribute(physical_dev,
                                                        ABS_MT_ORIENTATION,
                                                        cmd->orientation, true);
    else if (supports_abs_axis(physical_dev, ABS_MT_ORIENTATION) &&
             cmd->action == op_down)
        vt.orientation[slot] = scale_contact_attribute(physical_dev,
                                                        ABS_MT_ORIENTATION,
                                                        (int)((seed >> 24) % 257) - 128,
                                                        true);
}

int v_touch_event(const struct ls_touch_cmd *cmd)
{
    enum sm_req_op op;
    int slot;
    int x;
    int y;
    int ret = 0;

    if (!cmd)
        return -EINVAL;
    op = (enum sm_req_op)cmd->action;
    slot = cmd->slot;
    x = cmd->x;
    y = cmd->y;
    if (op < op_down || op > op_move || slot < 0 || slot >= VIRTUAL_SLOTS)
        return -EINVAL;

    mutex_lock(&vt_lock);
    if (!vt.initialized || !physical_dev) {
        ret = -ENODEV;
        goto out;
    }

    if (op == op_down || op == op_move) {
        if (x < 0 || y < 0 || x > vt.max_x || y > vt.max_y) {
            ret = -ERANGE;
            goto out;
        }
        update_virtual_contact_attributes(cmd);
    }

    if (op == op_move) {
        if (vt.tracking_ids[slot] != -1)
            ret = send_report_locked(slot, x, y, true);
    } else if (op == op_down) {
        if (vt.tracking_ids[slot] == -1) {
            vt.tracking_ids[slot] = next_tracking_id();
            ret = send_report_locked(slot, x, y, true);
            if (ret) {
                vt.tracking_ids[slot] = -1;
                goto out;
            }
            if (vt_active_count() == 1) {
                /* From this point a physical BTN_TOUCH/BTN_TOOL release is
                 * suppressed until the last virtual slot is released. */
                set_global_key_bits(physical_dev, false);
                global_keys_locked = true;
            }
        }
    } else if (op == op_up) {
        if (vt.tracking_ids[slot] != -1) {
            vt.tracking_ids[slot] = -1;
            ret = send_report_locked(slot, 0, 0, false);
            if (!vt_active_count()) {
                set_global_key_bits(physical_dev, true);
                global_keys_locked = false;
            }
        }
    }
out:
    mutex_unlock(&vt_lock);
    return ret;
}

int v_touch_get_physical_state(struct ls_physical_touch_state *out)
{
    struct input_mt *mt;
    unsigned long active_mask = 0;
    unsigned long released_mask;
    int slot = -1;
    int i;

    if (!out)
        return -EINVAL;
    memset(out, 0, sizeof(*out));

    mutex_lock(&vt_lock);
    if (!vt.initialized || !physical_dev || !physical_dev->mt) {
        mutex_unlock(&vt_lock);
        return -ENODEV;
    }

    mt = physical_dev->mt;
    for (i = 0; i < physical_slots; i++) {
        if (input_mt_get_value(&mt->slots[i], ABS_MT_TRACKING_ID) != -1)
            active_mask |= BIT(i);
    }
    released_mask = last_physical_mask & ~active_mask;
    for (i = 0; i < physical_slots; i++) {
        int candidate = (physical_cursor + 1 + i) % physical_slots;
        if (active_mask & BIT(candidate)) {
            slot = candidate;
            break;
        }
    }
    if (slot >= 0)
        physical_cursor = slot;

    out->abi_version = LS_TOUCH_ABI_VERSION;
    out->seq = ++physical_seq;
    out->active = slot >= 0;
    out->slot = slot >= 0 ? slot : 0;
    out->max_x = vt.max_x;
    out->max_y = vt.max_y;
    out->released_mask = (int)released_mask;
    if (slot >= 0) {
        out->x = input_mt_get_value(&mt->slots[slot], ABS_MT_POSITION_X);
        out->y = input_mt_get_value(&mt->slots[slot], ABS_MT_POSITION_Y);
        if (supports_abs_axis(physical_dev, ABS_MT_PRESSURE))
            out->pressure = input_mt_get_value(&mt->slots[slot], ABS_MT_PRESSURE);
        if (supports_abs_axis(physical_dev, ABS_MT_TOUCH_MAJOR))
            out->touch_major = input_mt_get_value(&mt->slots[slot], ABS_MT_TOUCH_MAJOR);
        if (supports_abs_axis(physical_dev, ABS_MT_TOUCH_MINOR))
            out->touch_minor = input_mt_get_value(&mt->slots[slot], ABS_MT_TOUCH_MINOR);
        if (supports_abs_axis(physical_dev, ABS_MT_ORIENTATION))
            out->orientation = input_mt_get_value(&mt->slots[slot], ABS_MT_ORIENTATION);
        if (supports_abs_axis(physical_dev, ABS_MT_PRESSURE))
            out->attribute_mask |= LS_TOUCH_ATTR_PRESSURE;
        if (supports_abs_axis(physical_dev, ABS_MT_TOUCH_MAJOR))
            out->attribute_mask |= LS_TOUCH_ATTR_TOUCH_MAJOR;
        if (supports_abs_axis(physical_dev, ABS_MT_TOUCH_MINOR))
            out->attribute_mask |= LS_TOUCH_ATTR_TOUCH_MINOR;
        if (supports_abs_axis(physical_dev, ABS_MT_ORIENTATION))
            out->attribute_mask |= LS_TOUCH_ATTR_ORIENTATION;
    }
    last_physical_mask = (u32)active_mask;
    mutex_unlock(&vt_lock);
    return 0;
}

/* The reference slot-sharing path has no physical-coordinate redirect
 * operation.  Keep the ioctl entry points for ABI compatibility. */
int v_touch_redirect_physical(int slot, int x, int y)
{
    if (slot < 0 || slot >= MAX_TOUCH_SLOTS || x < 0 || y < 0)
        return -EINVAL;
    return -EOPNOTSUPP;
}

int v_touch_clear_physical_redirect(int slot)
{
    if (slot < 0 || slot >= MAX_TOUCH_SLOTS)
        return -EINVAL;
    return 0;
}
